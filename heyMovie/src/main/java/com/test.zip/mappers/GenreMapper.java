package com.mappers;
/*
public class GenreMapper {
}*/


import com.dtos.GenreDto;
import com.entities.Genre;
import org.springframework.stereotype.Component;

/**
 * Mapper responsable de la conversion entre les entités Genre et les DTOs GenreDto.
 * Un mapper permet de séparer la couche de persistance de la couche de présentation.
 *
 * Points clés du pattern Mapper :
 * - Conversion bidirectionnelle entre DTO et Entity
 * - Gestion des null-safety
 * - Pas de logique métier, uniquement de la transformation
 */
@Component
public class GenreMapper {

    /**
     * Convertit une entité Genre en DTO GenreDto
     * Cette méthode est utilisée pour exposer les données aux clients de l'API
     *
     * @param genre l'entité à convertir
     * @return le DTO correspondant ou null si l'entité est null
     */
    public GenreDto toDto(Genre genre) {
        if (genre == null) {
            return null;
        }

        GenreDto GenreDto = new GenreDto();
        //GenreDto.setId(genre.getId());
        GenreDto.setTitre(genre.getTitre());
        GenreDto.setMovies(genre.getMovies());
        //GenreDto.setGenres(genre.getGenres());
        return GenreDto;
    }

    /**
     * Convertit un DTO GenreDto en entité Genre
     * Cette méthode est utilisée pour persister les données reçues des clients
     * Note: La date de naissance n'est pas dans le DTO mais est présente dans l'entité
     *
     * @param GenreDto le DTO à convertir
     * @return l'entité correspondante ou null si le DTO est null
     */
    public Genre toEntity(GenreDto GenreDto) {
        if (GenreDto == null) {
            return null;
        }

        Genre genre = new Genre();
        // On ne set l'ID que s'il existe (cas d'une mise à jour)
        if (GenreDto.getTitre() != null) {
            genre.setTitre(GenreDto.getTitre());
        }
        // Il faut faire les autres !!! imperativement ! fait vite fait !
        genre.setTitre(GenreDto.getTitre());
        genre.setMovies(GenreDto.getMovies());
        return genre;
    }
}