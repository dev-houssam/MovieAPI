package com.dtos;

import com.entities.Genre;
import com.entities.Movie;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class GenreDto {
    @NotNull
    private Long id;
    @NotBlank(message = "Le titre est obligatoire")
    private String titre;

    List<Movie> movies;
}
