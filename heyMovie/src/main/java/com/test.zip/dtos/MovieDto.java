package com.dtos;

import com.entities.Genre;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class MovieDto {
	
	@NotNull
	private Long id;
	
	@NotBlank(message = "Le titre est obligatoire")
	private String titre;
	
	@NotBlank(message = "La genre est obligatoire")
	private List<Genre> genres;

	@NotBlank(message = "L'annee de réalisation est obligatoire")
	private LocalDate anneeRealisation;

	@NotBlank(message = "Le prix de location est obligatoire")
	private Long prixLocation;

	@NotBlank(message = "L'age minimum est obligatoire")
	private Long ageMinimum;
}
