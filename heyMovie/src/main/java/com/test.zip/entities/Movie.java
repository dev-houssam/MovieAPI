package com.entities;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.*;

import lombok.Data;

@Entity
@Data
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;
	private String titre;

	@ManyToMany
	private List<Genre> genres;
	private LocalDate anneeRealisation;
	private Long prixLocation;
	private Long ageMinimum;
	
}
